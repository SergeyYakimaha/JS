var Collection = require('ampersand-collection');

module.exports = Collection.extend(require('ampersand-collection-underscore-mixin'));
