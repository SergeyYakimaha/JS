var AmpersandCollection = require('ampersand-collection');
var Callback = require('./callback');

module.exports = AmpersandCollection.extend({
    model: Callback
});
