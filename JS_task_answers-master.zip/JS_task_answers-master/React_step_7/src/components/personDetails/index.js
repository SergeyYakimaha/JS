import PersonDetails from './personDetails';
export default PersonDetails;