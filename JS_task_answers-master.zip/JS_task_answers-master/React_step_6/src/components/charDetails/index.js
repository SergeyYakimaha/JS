import CharDetails from './charDetails';
export default CharDetails;