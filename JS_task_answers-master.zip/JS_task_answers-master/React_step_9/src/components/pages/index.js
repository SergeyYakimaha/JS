import CharacterPage from './characterPage';
import BooksPage from './booksPage';
import HousesPage from './housesPage';
import BooksItem from './booksItem';
export {
    CharacterPage,
    BooksPage,
    HousesPage,
    BooksItem
}