import CartTable from './cart-table';

export default CartTable;