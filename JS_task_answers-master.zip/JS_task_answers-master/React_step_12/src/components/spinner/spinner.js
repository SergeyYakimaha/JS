import React from 'react';

const Spinner = () => {
    return <div className="spinner">loading...</div>
}

export default Spinner;