import ErrorBoundry from './error-boundry';

export default ErrorBoundry;