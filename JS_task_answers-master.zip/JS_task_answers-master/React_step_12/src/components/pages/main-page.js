import React from 'react';
import MenuList from '../menu-list';

const MainPage = () => {
    return (
        <MenuList/>
    )
}

export default MainPage;
